
<template>
    <div >

        <h1>이동 완료</h1>
        <h1>{{$route.params.text}}</h1>
    </div>
</template>

