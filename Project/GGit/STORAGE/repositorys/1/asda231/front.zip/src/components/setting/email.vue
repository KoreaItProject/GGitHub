<template lang="">
    <div>
        email
    </div>
</template>
<script>
export default {};
</script>
<style lang="">
</style>