//export const USER_ID = "USER_ID";
export const USER_EMAIL = "USER_EMAIL";
export const USER_IDX = "USER_IDX";
export const ERROR_STATE = "ERROR_STATE";
export const IS_AUTH = "IS_AUTH";
export const IS_LOGIN = "IS_LOGIN";
