<template lang="">
    <div style="width:100%; text-align:center;">
        <div style="margin:0 auto;width:100%;" > 
            
            <img src='@/assets/imgs/main/pagenotfound.svg' width=100% />
        </div>
        
    </div>
</template>
<script>
export default {};
</script>
<style lang="">
</style>