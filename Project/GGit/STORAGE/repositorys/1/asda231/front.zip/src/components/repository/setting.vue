<template lang="">
    <div class="setting_top_container">
        <div class="setting_container_right">
            
        </div>
        <div class="setting_container_left">

        </div>
    </div>
</template>
<script>
export default {};
</script>
<style lang="sass">
@import "src/assets/sass/repository/setting"
</style>