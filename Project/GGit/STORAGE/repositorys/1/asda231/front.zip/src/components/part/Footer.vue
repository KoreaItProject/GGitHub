<template>
  <div class="footer_container">
    <div class="">
      <div class="mt-2 mt-lg-0 d-flex flex-items-center">
        <a
          href="http://ggit.me"
          style="position: absolute; margin-top: 3px; margin-left: 3px"
        >
          <img class="logo" src="@/assets/imgs/logo/logoblack.png" />
        </a>

        <span style="margin-left: 40px"> © 2022 GGIT, Inc. </span>
        <h3 class="sr-only" id="sr-footer-heading" style="margin-left: 15px">
          웹프로젝트
        </h3>
      </div>
    </div>
    <div>
      <ul class="" style="color: #2a65d1">
        <li class="footer_members">
          <a href="https://github.com/eak00700">민준성</a>
        </li>
        <li class="footer_members">
          <a href="https://github.com/leetaehyeon123">이태현</a>
        </li>
        <li class="footer_members">
          <a href="https://github.com/JIN-RYEOL">김진렬</a>
        </li>
      </ul>
      본 웹페이지는 신촌
      <a style="color: #2a65d1" href="https://koreaisacademy.com/"
        >코리아IT아카데미</a
      >
      팀프로젝로 학습용 사이트입니다.
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="sass">
@import 'src/assets/sass/part/footer'
</style>  