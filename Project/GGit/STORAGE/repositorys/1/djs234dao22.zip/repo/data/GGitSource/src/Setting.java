public class Setting {
    String imgPath = "C:/gitdata/GGitHub/GGitSource/src/img/";

    public String getImgPath() {
        return imgPath;
    }

}
